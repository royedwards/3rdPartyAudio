#include <iostream.h>
#include <math.h>

#include "global.h"

static list<int> li;

